#!/bin/bash
java -jar lib/cddatse.jar $1
