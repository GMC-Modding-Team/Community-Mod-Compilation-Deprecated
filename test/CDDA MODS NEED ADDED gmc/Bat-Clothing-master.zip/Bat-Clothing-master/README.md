# Bat-Clothing
A Cataclysm: Dark Days Ahead mod adding armor and weapons from a certain superhero.
Made this for a cousin of mine who was disappointed you couldn't be Batman in Cataclysm. Enjoy!
