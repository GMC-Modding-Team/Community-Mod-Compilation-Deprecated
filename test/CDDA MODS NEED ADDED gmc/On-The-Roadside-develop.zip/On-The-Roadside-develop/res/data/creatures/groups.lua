return {
    allied = {
        "class_stalker"
    },
    neutral = {
        "class_dog"
    },
    enemy = {
        "class_bandit",
        "class_dog"
    }
}
