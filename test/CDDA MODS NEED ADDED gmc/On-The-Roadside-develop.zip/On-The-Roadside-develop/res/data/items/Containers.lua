return {
    {
        id            = "bag_small_backpack",
        idDesc        = "bag_small_backpack_desc",
        itemType      = "Container",
        weight        = 1.7,
        volume        = 1.0,
        equippable    = true,
        permanent     = false,
        tags = {
            'humanoid'
        },
        carryCapacity = 15
    }
}
