return {
    {
        id         = "misc_nail",
        idDesc     = "misc_nail_desc",
        itemType   = "Miscellaneous",
        weight     = 0.1,
        volume     = 0.1,
        equippable = false,
        permanent  = false
    },
    {
        id         = "misc_splintered_wood",
        idDesc     = "misc_splintered_wood_desc",
        itemType   = "Miscellaneous",
        weight     = 3.0,
        volume     = 2.0,
        equippable = false,
        permanent  = false
    },
    {
        id         = "misc_glass_shard",
        idDesc     = "misc_glass_shard_desc",
        itemType   = "Miscellaneous",
        weight     = 0.6,
        volume     = 0.5,
        equippable = false,
        permanent  = false
    },
    {
        id         = "misc_ceramic_shard",
        idDesc     = "misc_ceramic_shard_desc",
        itemType   = "Miscellaneous",
        weight     = 0.6,
        volume     = 0.5,
        equippable = false,
        permanent  = false
    }
}
