========================
!! WARNING !!
========================

The default texture pack will be overwritten automatically.

If you want to create your own texture pack you should copy and rename the default pack.
