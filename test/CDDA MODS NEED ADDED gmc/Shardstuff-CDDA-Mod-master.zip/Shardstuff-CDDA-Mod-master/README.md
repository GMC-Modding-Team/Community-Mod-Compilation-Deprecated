# Shardstuff-CDDA-Mod
Adds several large vehicle parts, overrides some from base game, and buffs gates controls to match the durability of the gates themselves to reduce chances of them being destroyed when you find them.

Can add to an existing world by modifying the save's mods.json and adding "shardstuff" to the list, with a comma behind every entry except the last.


# This mod is basically abandoned and only edited for bugfixes, and even then not always.  Anyone who wants to take it over is free to do so, and do anything with it.


# Contents:
Gatebuff.json - contains buffs for gate control durability

Override-vehicleparts.json - Curtains become multitile so you can open/close all at once, boom crane can be folded at full volume so you don't have to weld it to a frame any time you move around.

Vehiclestuff.json: Contains several new items listed below

100/200L external tanks can now be installed internally in the center slot (same as seats, aisles, cargo spaces, and crafting stations)
  
Storage battery array: put eight storage batteries into one tile as a floor to ceiling block (uses center slot)
  
Massive electric motor: 2.5x large electric motor strength, 3.5x power use
  
Storage rack: instead of just a spot on the floor like a cargo space, an extra large rack to be able to extend your pile all the way up
  
Air raid siren: hook up a bunch of truck horns for a blast of noise fit to wake the dead, will attract hordes from quite a distance
