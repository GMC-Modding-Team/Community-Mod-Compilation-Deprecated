# CDDA Trailer Park Mod

Adds `trailer parks` to map generation, as well as regular and small trailers.

~~*Everything works?*~~ **Everything works**
+ might play a little with the items that get spawned in the RVs
+ ~~does it spawn on the map enough? too much? i dunno~~
+ ~~the monsters that spawn there probably need balancing~~
+ is that wall type okay for the shelter? i don't know if i like it
+ ~~things should spawn in the dumpsters, but they don't yet~~
+ another version of the park with bandit fortifications and glass pits and stuff
+ ~~how to basement? make one down from the shelter? it's a storage area? question mark?~~
+ bandits totally use the storage area for a makeshift prison
