# InfStamina-CDDA-Mod
Simple mod that adds a mutation setting stamina regen to absurd levels to practically disable the stamina system.

Can add to an existing world by modifying the save's mods.json and adding "InfStamina" to the list, with a comma behind every entry except the last.  Can add the mutation to an existing character via using debug menu, mutate, then using / to search for stamina.
