# XEAS V0.8
Add new Xeno-Adapted Stuff. Close to hi-tech content. Includ armor set (slightly better protection than survival armor, less encumbrance), new knife (better butchering, impression damage) and vortex bag (120 L, tiny size, no encumbrance). Craft recipes in vanilla lab journal. High price. Late game content!

Planned:
- XEAS full suit (need all parts);
- XEAS power armor.

How to install:
1) Extract "XEAS" (no XEAS-master) into the mod folder of CDDA.
2) Done.

How to update:
1) Delete the XEAS mod from mod folder of CDDA.
2) Extract "XEAS" (no XEAS-master) into the mod folder of CDDA.
3) Done.
