# Unnerf Spears-CDDA-Mod
Removes fragile flag from knife spear and forked spear, undoes massive awlpike nerf.

Can add to an existing world by modifying the save's mods.json and adding "Unnerf_Spears" to the list, with a comma behind every entry except the last.