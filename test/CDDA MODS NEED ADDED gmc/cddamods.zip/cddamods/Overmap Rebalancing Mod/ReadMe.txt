::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::                                                                                                                                                  ::
:: = Welcome to the "Overmap Rebalancing" Mod for Cataclysm: Dark Days Ahead = :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
::                                                                                                                                                  ::
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

= CONTENT =

1) Configuring "Overmap Rebalancing"
2) Credits

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

1) Configuring "Overmap Rebalancing"

To configure "Overmap Rebalancing" is only necessary in case you downloaded the archive "Overmap_Rebalancing_(Full_Pack)" and...

  a) ...don't use all supported mods (game included mods: "Arcana and Magic Items", "More Locations", "Tall Buildings", "PKs Reimagining"; external mod: "Mining Mod")...
  b) ... and/or don't want to use all included mods ("AddBandits", "Animatronics", "DinoMod", "Extended Buildings", "Parks and Recreation Buildings").



::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::


2) Credits

    Thanks to this ladies and gentlemen for their fantastic work:

    "Add Bandits" was created by GovTD.
      (Profile: http://smf.cataclysmdda.com/index.php?action=profile;u=4954)
    It can be found at http://smf.cataclysmdda.com/index.php?topic=12255.0
    All rights belong to GovTD.


    "Animatronic Monsters (V 2.0b)" was created by Lanceo90.
      (Profile: http://smf.cataclysmdda.com/index.php?action=profile;u=1243)
    It can be found at http://smf.cataclysmdda.com/index.php?topic=8258.0
    All rights belong to Lanceo90.


    "DinoCataclysm Mod" was created by DinoCat.
      (Profile: http://smf.cataclysmdda.com/index.php?action=profile;u=29)
    It can be found at http://smf.cataclysmdda.com/index.php?topic=21.0
    All rights belong to DinoCat.


    "Extended Buildings (V1.0) - BAD MOON RISING" and "Parks and Recreation Building Pack V1.0" were created by Whaley.
      (Profile: http://smf.cataclysmdda.com/index.php?action=profile;u=3470)
    "Extended Buildings" can be found at http://smf.cataclysmdda.com/index.php?topic=8579.0,
    "Parks and Recreation Buildings" at http://smf.cataclysmdda.com/index.php?topic=12533.0
    All rights belong to Whaley.
