# Gunslinger of Eld

*this mod is still very much a W.I.P,  
please don't expect it to always be working*

---

gunslinger starts with a sandalwood revolver - a powerful sidearm that fires .60 big bore cartridges.  
your character starts with X rounds of .60 of big bore. this ammo cannot be found in the world, only created by the gunslinger.
                                                                                      to create ammo, you start with a gunslinger's kit. this tool can disassemble all types of found ammunition for use in recrafting your spent rounds. the sandalwood revolver catches spent rounds automatically and can be upgraded twice - to the clockwork revolver then the masterwork revolver. you also start with a bird skull necklace to mediate with, a bandolier holster to store your gun and a knife sheathed in your worn leather boots.  

your ammunition comes in four types -  

**.60 big bore** - good range with average damage  
**.60 lightweight** - excellent range but low damage  
**.60 Cherry pie** - good range, average damage and ignition on impact  
**.60 showstopper** - low range with excellent damage, but LOUD  

if lost, most of your starter items can be crafted using the recipes in your journal - though most are not simple. the journal also contains the recipe for a target dummy, for training up your ranged skills - fragile and a little tricky to make, the target dummy can be set up indoors for those long winters when you have nothing to shoot at - as well as a few others.  

## work in progress for completion
                                                                                      
+ all kinds of things are missing descriptions  
+ what about maybe a kind of clockwork slingshot for a silent ranged attack?  
+ showstoppers might be too powerful, though they attract every damn zed around  
+ the bandolier holster is weird. i don't know if it's working properly  
                                                                                      
### new items

sandalwood revolver - high powered custom revolver, holds 5 bullets  
> sandalwood can be upgraded : clockwork sandalwood : masterwork sandalwood  
leather satchel - medium capacity, wearable leather container  
gunslinger's kit - firearm repair + bullet puller + custom ammo tool, powered using wood gasification  
bandolier holster - holster with custom ammo capacity  
training dummy - craftable mob for training ranged skills  

### new martial art - gunslinger of eld - ~~probably~~ definitely not up to date

**I aim with my eye** - static bonus to hit using revolver  
**I shoot with my mind** (marksmanship 4 required) - static bonus to DEX & PER  
**I kill with my heart** (pistol 8 required) - static bonus damage using revolver  

**Swift like a bullet** - bonus to damage + block on dodge (stacks x3)  
**Perfectly coiled mechanism** - extra chance to dodge when moving (stacks x2)  

**Critical Attack** (pistol 4 required) - armor penetration + extra damage  
**Feint Attack** (pistol 5 required) - reduced movecost/fast attack  
**Fast Attack** (pistol 7 + Feint Attack required) - fast attack + massive damage
**Piercing Blast** (pistol 10 required) - massive damage + armor penetration

### notes

this class is hard to use without all the tools you need, so there isn't currently a way to learn the martial art from a manual like all the others.

*tinder and ember holder from -- WHATMOD? survival tools?
