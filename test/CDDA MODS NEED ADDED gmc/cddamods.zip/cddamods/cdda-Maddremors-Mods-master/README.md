# Maddremor's Mods
A collection of my minor mods. Not that serious stuff.

# Egg-Eggplant-Plant-Combo-Seed-Mod
A mod that adds eggplants and the ability to craft a mutated plant that yields both eggplants and actual eggs.

# MaddreMod
A random grab bag of whatever ideas I get.

# Sarcophagi-Access
An alternate method to get access to the Hazardous Waste Sarcophagus.

# Sunken-Bridges
Makes bridges count as crossable for both cars and boats. Has the side effect of allowing fish to swim over bridges.

# The-Cool-Mod
Adds a dragable cooler. Cooling not guaranteed.