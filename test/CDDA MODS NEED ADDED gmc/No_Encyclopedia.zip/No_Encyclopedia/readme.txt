this mod requires Cataclysm++
(https://github.com/Noctifer-de-Mortem/nocts_cata_mod)

Author
	Ezsk

Version History
	2.0 Added support for the new advanced encyclopedia
	1.0 released

License
	this modification are released under the "Creative Commons Attribution ShareAlike 3.0"