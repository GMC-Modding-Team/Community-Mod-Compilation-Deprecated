# Disable Bots-CDDA-Mod
If you can hack it, you can turn it into an item form.  Exception: Broken cyborg.  (Base game + national guard camps)

Can add to an existing world by modifying the save's mods.json and adding "disable_bots" for base game, and "disable_bots_natcamp" as well if you have national guard camp to the list, with a comma behind every entry except the last.