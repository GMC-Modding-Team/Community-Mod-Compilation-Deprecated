# Locked and Loaded
Adds more guns and ammo types for those gun nuts.

Click the green button and then download zip file.

Copy and paste file into your CDDA mod file.
