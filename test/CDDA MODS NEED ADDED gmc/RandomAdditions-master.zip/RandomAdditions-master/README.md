This mod is random additions I've added to the game when the idea comes to me. The additions being completely random gives this mod an interesting bit of realistic style but rather silly pleasure.

An example would be "Lost Dominant" which is a pairing to the "Lost Submissive" profession.

Link to the github of the game: https://github.com/CleverRaven/Cataclysm-DDA