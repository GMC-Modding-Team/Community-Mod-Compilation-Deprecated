# Visible-Scary-Shadies-CDDA-Mod
Makes shady zombies visible at night, increases speed, makes them harder to hit, and likely to cause you to get swarmed.

Can add to an existing world by modifying the save's mods.json and adding "visible-scary-shadies" to the list, with a comma behind every entry except the last, also add "visible-scary-shadies-pks" if you use PKs mod.