# Adurnsyl Assorted Arms and Armour

The initial build

this version includes
----------------------------------
every hi-point known to man (.38m .40, .45, 9mm )

new ammo type: 20x28mm
   + 20x28mm frag
   + 20x20mm HEDP
   + 20x28mm HE

new ammo type: 7.92x33 kurtz
   + 7.92x33 FMJ
   + 7.92x33 FMJBT

+ xm-29 OICW (.223 rifle with integrated 20x28mm grenade laucher)

+ xm-25 (20x28mm)

+ xm-231 (.223)

+ m-231 (.223)

+ a bunch of stg-44 rifles (7.62x39, .223, 7.92x33)

+ IA2 (.223)

+ IA2 CQC (.223)

+ IA2 carbine (.223)

+ IA2 DMR .(.308)

+ IA2 Sniper (.308)

+ RDB (.223)

+ M16a1 (.223)

+ M16a2 (.223)

+ M16a3 (.223)

+ RFB (.308)

+ vz58p (7.62x39)

+ vz58v (7.62x39)

+ vz2008p (7.62x39)

+ vz2008v (7.62x39)

+ M10X (7.62x39)

-------------
New uniforms
-------------
+ ACU's in both UCP and Multicam

+ New helmets with changable helmet covers

+ IOTV's in both UCP and Multicam

----------------------------------------------------
build 2
----------------------------------------------------
Most of the m16's and ar pattern rifles in game can now be stripped down to an upper and lower receiver and mixed and matched to make new franken rifles.
This also applies to the STG-44's. The STG-44's have 4 componenets (the barrel kit, lower receiver, upper receiver, and the stock/ receiver cap) that can be mixed and matched to create new rifles.

New ammo type: 300 blackout
   + FMJ (full metal jacket)
   + JHP (jacketed hollow points)
   + AP (armour peircing)

new magazines for said ammo type and new rifles that use 300 blackout (10, 20, 30, and 50 round magazines)

added 300 blackout upper receivers for AR-15 pattern rifles
   + a1 upper in 300 blackout
   + a2 upper in 300 blackout
   + a3 upper in 300 blackout

added 300 blackout barrel kit for the STG-44 rifles

There might be a few other things I missed. this is the first big project I've worked on and I've had a hard time keeping track of my work.

----------------
build 3
----------------

More military vests!

 + IOTV mk2 - twice as heavy way more encumbering, but it's super tankey (and hopefully not stupidly OP)
 + plate carrier - it's a very very light vest. Hardly any encumberance, but it won't take a lot of abuse

Theres also an armours only version and a weapons only version now for those who only want more armours or only want more weapons.
----------------
Build 4
----------------

 3 more guns can now be disasembled into their components
  + glock 19 (receiver, barrel, slide)
  + CX4 (upper receiver, lower receiver, bolt group)
  + Calico SMG (upper receiver, lower receiver, bolt group)

 A few new firearms
  + pm-83p : a compact SMG chambered in 9x19mm (comes with either a 15rnd or a 30rnd magazine)
  + pm-63 : same as the pm-83p just chambered in 9x18 makarov (comes with either a 15rnd or a 30rnd magazine)

 New armors
  + TALOS armor and helmet
  + IIa police vest
  + IIIa police vest

I'm getting rid of the 2 other versions for now. With school and NREMT classes I don't really have the time or energy to keep up with 3 different packs right now.
I will probably split the main pack back up once I've added more in.
___________________________________________________________________________________________



To install this mod simply place the aaa folder into the mods folder of CDDA (Where ever your CDDA file is at\Cataclysm Dark Days Ahead\cdda\data\mods)
After dropping it in there just start the game and activate the mod pack after the game loads up
