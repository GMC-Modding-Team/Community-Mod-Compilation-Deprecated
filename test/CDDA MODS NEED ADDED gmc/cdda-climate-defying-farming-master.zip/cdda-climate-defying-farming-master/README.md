# cdda-climate-defying-farming
A farming mod for Cataclysm: Dark Days Ahead. Adds different crops that would not grow in New England or are somewhat fantastical.

Currently contains coffee, poppy, eggplants, and nu-bamboo (read: sticks).
