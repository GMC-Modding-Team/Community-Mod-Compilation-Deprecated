# CDDA Companion Potato

**Now in Crazy Cataclysm! \o/**

**Adds the companion potato, a very important tool for surviving after the collapse of civilisation.**

Can be found in `Robots for Fun & Profit` when Electronics is level 4.  
*Requires Electronics 8 to construct.*

### Components
+ 1 tool with with screw driving or 1 or more.
+ 1 circuit board
+ 3 electronic scraps
+ copper wire (5)
+ battery (1)
+ raw potato

*Try new radio control!*
