-- MOD NINJA.
game.add_item_to_group("museum_misc", "ninja_tengu_mask", 5)
