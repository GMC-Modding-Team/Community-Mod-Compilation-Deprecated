# drinkinghats

Drinking Hats is a light-hearted mod for Cataclysm:Dark Days Ahead made because we want to store liquids on our heads and drink hands-free!

Most drinking headgear variants can be crafted using a Rubber Hose, 2 aluminum cans, 2 small bottles, or 2 hip flasks.


Latest releases downloads [https://github.com/Tsunder/drinkinghats/releases/latest](https://github.com/Tsunder/drinkinghats/releases/latest)
