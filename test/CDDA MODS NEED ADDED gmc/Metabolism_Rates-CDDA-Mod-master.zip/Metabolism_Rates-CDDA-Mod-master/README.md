# Metabolism Rates-CDDA-Mod
Adds several mutations that alter hunger and thirst rates by reducing them to 1/2, 1/4, or 1/10th.

Can add to an existing world by modifying the save's mods.json and adding "Metabolism_Rates" to the list, with a comma behind every entry except the last.  Mutations can be added to an existing character with debug menu, mutate, then use search for reduction with the / key.