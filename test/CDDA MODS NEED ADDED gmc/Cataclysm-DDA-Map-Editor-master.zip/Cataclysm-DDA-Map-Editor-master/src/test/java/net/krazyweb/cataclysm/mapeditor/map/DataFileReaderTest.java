package net.krazyweb.cataclysm.mapeditor.map;

import org.testng.annotations.Test;

public class DataFileReaderTest {

	@Test
	public void testLoadMapgenSection() throws Exception {

	}

}