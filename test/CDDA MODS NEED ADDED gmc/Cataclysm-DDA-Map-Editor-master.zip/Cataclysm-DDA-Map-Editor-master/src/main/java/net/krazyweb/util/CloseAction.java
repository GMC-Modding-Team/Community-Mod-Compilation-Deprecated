package net.krazyweb.util;

public enum CloseAction {
	SAVE, WITHOUT_SAVE
}
