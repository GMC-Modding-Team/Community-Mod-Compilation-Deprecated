package net.krazyweb.cataclysm.mapeditor.map.undo;

public interface UndoBufferListener {
	public void undoBufferChanged();
}
