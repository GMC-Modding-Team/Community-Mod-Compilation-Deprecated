package net.krazyweb.cataclysm.mapeditor.events;

public class MapChangedEvent {
}
