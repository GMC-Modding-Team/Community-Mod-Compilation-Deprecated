package net.krazyweb.cataclysm.mapeditor.map.data.tilemappings.editorcontrollers;

import net.krazyweb.cataclysm.mapeditor.map.data.tilemappings.TileMapping;

public abstract class MappingController {
	public abstract void setMapping(final TileMapping mapping);
}
