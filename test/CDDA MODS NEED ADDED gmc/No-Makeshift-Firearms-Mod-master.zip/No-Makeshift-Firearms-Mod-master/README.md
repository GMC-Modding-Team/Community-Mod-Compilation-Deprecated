# No-Makeshift-Firearms-Mod
A small exclusion mod that removes crafted pipe and scrap metal firearms that fire conventional cartridges from Cataclysm-DDA.

The original game this is for can be found here https://cataclysmdda.org/
