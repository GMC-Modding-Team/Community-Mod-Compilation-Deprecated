##### Files that encounter an error are taken here
When looking for a specific `id` (definitely because of bad file sorting), it ends up with the loading screen error. It is not fatal, but makes a feature broken throughout the game.

For the solution, I seperate them into a new folder, to make them look for the specific `id` after that `id` has loaded.