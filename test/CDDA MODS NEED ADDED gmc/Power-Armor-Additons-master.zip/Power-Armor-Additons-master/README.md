# Power-Armor-Additons
Power armor mod for Cataclysm DDA
Adds a magnetic back holster and waist holster found just about everywhere hauling frames and power armor can be found.
