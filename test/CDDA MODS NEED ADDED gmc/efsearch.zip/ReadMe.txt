Effective File Search v6.8  Brief overview.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Effective File Search (EFS) is a powerful but easy
to use search tool. Search any files on your computer
or local network with this effective software.
EFS is a real replacement for the Windows Search utility.
          
Main features:

   - Search of files in folders or search results

   - Filtering by file date and size

   - Search of files containing text or hex

   - Support of all popular file formats (MS Office files, PDF,
     RTF, HTML, OpenOffice and many other text and binary files)

   - Actions with search results (copy, delete, rename etc.) 

   - Windows Explorer functionality (icons, context menus etc.)

   - Advanced export and report functions for your business 

   - All results and parameters can be saved to file

   - Administrative options, automation (script language)
     and other advanced functions


Platform: Windows9X/2000/XP/Vista/7.
Hardware requirements: 32MB RAM, Pentium-133 MHz, 2MB Hard Disk.

This is freeware version.
