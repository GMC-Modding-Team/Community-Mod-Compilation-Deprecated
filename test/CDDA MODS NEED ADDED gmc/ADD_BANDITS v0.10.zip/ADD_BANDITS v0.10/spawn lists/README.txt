If you wish to use this mod along side PK's Rebalance mod without conflicting monster_group files, simply overwrite the pk_spawn_list in PK's mod with the one in here. If you aren't, the place the "gov_spawn_list" into the "bandit_mod" folder and play away.

If you want me to add more mod compatibility, let me know in the forums or email me at loganmangin216@gmail.com