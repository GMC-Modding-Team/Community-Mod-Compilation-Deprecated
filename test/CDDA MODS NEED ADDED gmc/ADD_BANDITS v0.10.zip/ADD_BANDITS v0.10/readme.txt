Hi, thanks for trying out my mod. Though it seems a little shallow at the moment, I do plan on working on this more and hopefully setting up a dungeon, some new buildings, and maybe even some other neat things like hiring the bandits or disguising yourself (though the later stuff will need a /lot/ more Lua knowledge, but hey, a goal's a goal)

To install this mod, simply drop the "bandit_mod" folder into :data/mods folder. 

Then, select which of the spawn_lists is compatible with the mods you have (I plan on adding more mod spawn-list compatibility later on).

If you have any feedback or anything, email me at loganmangin216@gmail.com