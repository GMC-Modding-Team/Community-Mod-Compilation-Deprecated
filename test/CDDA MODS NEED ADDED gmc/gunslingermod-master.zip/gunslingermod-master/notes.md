#Gunslinger of Eld
  
cowboy_hat  
boots_western  
bandana  
sherrifshirt  
waistcoast  
duster_leather  
XL_holster  
leather satchel (new object)
special ammo casings (like 30ish of them - 5 in gun, 10 in ammo belt (to mimic fast reloads?) plus 20 in the bag? that's 35)
custom ammo belt (0 encumbrance, for special ammo)

`Book of Eld (recipes)`
+ "slingshot"
+ training gun (special ammo casing)
+ sandlewood gun (special ammo casing)
+ ammo types (special ammo casing)
+ gun modifications
+ slingshot modifications
+ bird skull necklace (PER + INT increase)
*guns have built in ammo catcher - will always use the same block of ammo)*

"gunslingers_kit" to disassembl
e unused ammo and make new ammo for the eld guns  
needs: "tool_quality": [ "HAMMER" ]  
`tool type - "puller" (kinetic), "press" (handpress and die)`  

*mean i'd have to change ALL the ammo types for disassembling - why not just have the guns fire a new type of ammo? then the kit is for that. and for disassembling them, so you can upgrade them.  
training gun could not have a brass catcher - or allow one to be added - so you have to be careful picking up the casings, as there's only a limited amount.  
at a higher level of fabrication + marksman + pistol then you could make them, again with the kit? or with anvil and shit? probably the latter, as they'd be powerful.*



I do not aim with my hand.  
He who aims with his hand has  
forgotten the face of his father.  
**I aim with my eye. (PER bonus)**

I do not shoot with my hand.  
He who shoots with his hand has  
forgotten the face of his father.

**I shoot with my mind. (INT + [ifpossible:skill, else:something])**

I do not kill with my weapon.  
He who kills with his weapon has  
forgotten the face of his father.

**I kill with my heart. (massive damage bonus)**