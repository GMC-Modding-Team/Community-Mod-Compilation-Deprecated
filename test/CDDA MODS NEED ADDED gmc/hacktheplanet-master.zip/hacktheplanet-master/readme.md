~~~~
"ident": "hacking.json",  
"category": "vintage cyberpunk gear",
"description": "A magazine written by and for hackers - the best, and by far the longest running hacker zine.  
This annual volume is packed with blueprints and circuit schematics.",
~~~~
adds the `Phrack Magazine, Annual Edition` to the game and to the hacker profession loadout and to the guerilla hacker, which has recipes for a bunch of stuff.  Including a portable balance transfer machine, handhelp gps devices and the ability to create science, gas and military cards using a homemade magnetic strip encoder. Also the Zintendo Power Glove.

if you want, see https://github.com/kettleswordfang/hacktheplanet/wiki for more on the phrack mod

